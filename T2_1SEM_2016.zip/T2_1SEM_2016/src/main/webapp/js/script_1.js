 
function cpf_mask(v){
	v=v.replace(/\D/g,"");               
	v=v.replace(/(\d{3})(\d)/,"$1.$2");
	v=v.replace(/(\d{3})(\d)/,"$1.$2");
	v=v.replace(/(\d{3})(\d)/,"$1-$2");
	return v;
};

function mascaraTelefone(mascara, documento){
  var i = documento.value.length;
  var saida = mascara.substring(0,1);
  var texto = mascara.substring(i);
  
  if (texto.substring(0,1) !== saida){
            documento.value += texto.substring(0,1);
  }
  
};
 
 function validar_CPF(cpf) 
 {
   var filtro = /^\d{3}.\d{3}.\d{3}-\d{2}$/i;
	
	if(!filtro.test(cpf))
	{
		window.alert("CPF inválido. Tente novamente.");
		document.cadastro.cpf.focus();
		document.cadastro.cpf.value = "";
		return false;
	}
   
	cpf = remove(cpf, ".");
	cpf = remove(cpf, "-");
	
	if(cpf.length !== 11 || cpf === "00000000000" || cpf === "11111111111" ||
		cpf === "22222222222" || cpf === "33333333333" || cpf === "44444444444" ||
		cpf === "55555555555" || cpf === "66666666666" || cpf === "77777777777" ||
		cpf === "88888888888" || cpf === "99999999999")
	{
		window.alert("CPF inválido. Tente novamente.");
		document.cadastro.cpf.focus();
		document.cadastro.cpf.value = "";
		return false;
   }

	soma = 0;
	for(i = 0; i < 9; i++)
	{
		soma += parseInt(cpf.charAt(i)) * (10 - i);
	}
	
	resto = 11 - (soma % 11);
	if(resto === 10 || resto === 11)
	{
		resto = 0;
	}
	if(resto !== parseInt(cpf.charAt(9))){
		window.alert("CPF inválido. Tente novamente.");
		document.cadastro.cpf.focus();
		document.cadastro.cpf.value = "";
		return false;
	}
	
	soma = 0;
	for(i = 0; i < 10; i ++)
	{
		soma += parseInt(cpf.charAt(i)) * (11 - i);
	}
	resto = 11 - (soma % 11);
	if(resto === 10 || resto === 11)
	{
		resto = 0;
	}
	
	if(resto !== parseInt(cpf.charAt(10))){
		window.alert("CPF inválido. Tente novamente.");
		document.cadastro.cpf.focus();
		document.cadastro.cpf.value = "";
		return false;
	}
	
	return true;
 };
 
 function validar_Nome(campo) { 
		
		
		if(campo === ""){
			alert ("Campo Obrigatório!!!");
			document.cadastro.nome.focus();
			return false;
		}
		if(campo.match(['[-@!#$%¨&*+_´`^~;:?áÁéÉíÍóÓúÚãÃçÇ|\?,./{}"<>()1234567890]'])){ 
			//encontrou então não passa na validação
			alert ("Campo Obrigatório - Não é permitido números ou caracteres especiais!!!") ;
			document.cadastro.nome.focus();
			document.cadastro.nome.value = "";
			return false; 
		} else { 
		
			//não encontrou caracteres especiais 
		
		  return true;
	}
 };
 
 function validar_Cidade(campo) { 
		
		
		if(campo === ""){
			alert ("Campo Obrigatório!!!");
			document.cadastro.cidade.focus();
			return false;
		}
		if(campo.match(['[-@!#$%¨&*+_´`^~;:?áÁéÉíÍóÓúÚãÃçÇ|\?,./{}"<>()1234567890]'])){ 
			//encontrou então não passa na validação
			alert ("Campo Obrigatório - Não é permitido números ou caracteres especiais!!!") ;
			document.cadastro.cidade.focus();
			document.cadastro.cidade.value = "";
			return false; 
		} else { 
		
			//não encontrou caracteres especiais 
		
		  return true;
	}
 };
 
 function validar_Campos(endereco){
	 if(endereco === ""){
		 alert("Campo Obrigatório!!!");
		 document.cadastro.endereco.focus();
		 
	 } 
 };
 

function validar_Email(){

if( document.cadastro.email.value==="" 
   || document.cadastro.email.value.indexOf('@')===-1 
     || document.cadastro.email.value.indexOf('.')===-1 )
	{
		alert( "Campo Obrigatório - Por favor, informe um E-MAIL válido!" );
		document.cadastro.email.focus();
		document.cadastro.email.value = "";
		return false;
	}
		
};

function validar_Senha(){
	if(document.cadastro.senha.value=="" 
		|| document.cadastro.senha.value.length = 6
			|| document.cadastro.senha.value.indexOf(' ','0')!= -1)
			{
				alert("Digite uma senha válida com 6 Caracteres!!!");
				document.cadastro.senha.focus();
			return false;
}
	

};

function validar_Sexo() {
        var comboSexo = document.getElementById("sexo");
        if (comboSexo.options[comboSexo.selectedIndex].value === "--Escolher Sexo--" ){
                alert("Selecione uma opção antes de prosseguir");
				document.cadastro.sexo.focus();
        }
				
		if (comboSexo.options[comboSexo.selectedIndex].value !== "--Escolher Sexo--" ){
                
				document.cadastro.telefone.focus();
		}
    };    
	
function validar_Promo(){
	
	var a = "A qualquer momento voce pode cancelar ";
	var b = "O recebimento dos e-mails de promoção ";
	var c = "Enviando um e-mail com o assunto parar Email ";
	var d = "para o endereço contato@estacio.br";
		
	if(document.cadastro.sim.checked  && document.cadastro.nao.checked || 
		document.cadastro.sim.checked === false  && document.cadastro.nao.checked === false){
	    alert("Campo Obrigatório - Escolha Sim ou Não");
		document.cadastro.sim.focus();
	return false;
	}
	
	if(document.cadastro.sim.checked === true && document.cadastro.nao.checked === false){
		
	document.getElementById("msgPromo").innerHTML = a + b + c + d;
	}
	else{
		document.getElementById("msgPromo").innerHTML = "";
	}
	return false;

		
};


function imprimir(){
		var cpf = document.cadastro.cpf.value;
		var nome = document.cadastro.nome.value;
		var endereco = document.cadastro.endereco.value;
		var cidade = document.cadastro.cidade.value;
		var sexo = document.cadastro.sexo.value;
		var telefone = document.cadastro.telefone.value;
		var email = document.cadastro.email.value;
		var obs = document.cadastro.obs.value;
		var promo = document.cadastro.promo.value;

	alert {	("cpf:" + cpf)+
			("nome:" + nome) +
			("Endereço: " + endereco) +
			("Cidade" + cidade) +
			("Sexo" + sexo) +
			("Telefone" + telefone) +
			("Email:" + email) +
			("Receber Promoções:" + promo) +
			("Observacao": + obs); 
	};
	};

function observacao(){

   var TextMsg =  cadastro.obs.value;
   if (TextMsg.length>200)
   {
       alert("Limite Excedido - Máximo 200 caracteres!!!!");
	   document.cadastro.obs.focus();
   return false;
    }
   
};

function validar_Maiuscula(a){
        v = a.value.toUpperCase();
        a.value = v;
    };
